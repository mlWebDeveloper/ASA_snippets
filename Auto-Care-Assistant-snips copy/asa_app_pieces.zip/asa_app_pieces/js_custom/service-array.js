// service-array.js

var serviceArray = [
	"--Select Service--",
	"Oil change", "Tune up", "Air filter change", "Fuel filter change", 
	"Transmission flush", "Radiator flush", "Tire rotation"
]; // End document.getElementById function	
