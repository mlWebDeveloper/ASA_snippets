// window.load.js

window.addEventListener("DOMContentLoaded", function doItAll() {
});